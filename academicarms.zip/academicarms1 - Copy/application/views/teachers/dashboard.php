 <div class="page-content fade-in-up">
                    <!-- BEGIN: Page heading-->
                    <div class="page-heading">
                        <div class="page-breadcrumb">
                            <h1 class="page-title">Dashboard</h1>
                        </div>
                        <div class="subheader_daterange" id="subheader_daterange"><span class="subheader-daterange-label"><span class="subheader-daterange-title"></span><span class="subheader-daterange-date"></span></span><button class="btn btn-floating btn-sm rounded-0" type="button"><i class="ti-calendar"></i></button></div>
                    </div><!-- BEGIN: Page content-->
                    <div>
                        
                        
                    </div><!-- END: Page content-->
                </div>